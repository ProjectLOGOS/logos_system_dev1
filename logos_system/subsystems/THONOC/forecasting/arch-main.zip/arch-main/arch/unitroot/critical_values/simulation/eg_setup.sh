#!/usr/bin/env bash

export MKL_NUM_THREADS=1
export OMP_NUM_THREADS=1
export VML_NUM_THREADS=1
