if [[ ${USE_CONDA} == "true" ]]; then
  source activate arch-test
fi