Change Logs
-----------

.. include:: changes/7.0.rst

=============
Past Releases
=============

.. toctree::
   :maxdepth: 1

   changes/6.0
   changes/5.0
   changes/4.0
   changes/3.0
   changes/2.0
   changes/1.0
