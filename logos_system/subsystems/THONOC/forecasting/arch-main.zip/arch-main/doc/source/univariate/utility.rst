Utilities
=========
Utilities that do not fit well on other pages.

.. module:: arch.utility.testing
   :synopsis: Utilities that do not fit well in other modules
.. currentmodule:: arch.utility.testing

Test Results
------------

.. autoclass:: WaldTestStatistic
   :members:
