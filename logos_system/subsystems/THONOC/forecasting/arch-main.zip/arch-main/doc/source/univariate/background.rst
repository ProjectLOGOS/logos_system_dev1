Theoretical Background
----------------------

*To be completed*